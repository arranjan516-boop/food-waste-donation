# Food Waste Donation System
BCA mini-project using HTML/CSS/JavaScript + PHP + MySQL.

Modules: Recipient, Donor, Collector, NGO, Admin.
Core features: food photo upload, 15 KM matching, food requests, acceptance locking, self-delivery/collector/NGO delivery.

## XAMPP
1. Copy this folder to C:\xampp\htdocs\
2. Start Apache and MySQL.
3. Import database/food_waste_donation.sql in phpMyAdmin.
4. Open http://localhost/food_waste_donation/
5. Database settings are in config/database.php.
