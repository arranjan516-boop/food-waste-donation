<?php require_once 'config/constants.php';require_once 'includes/functions.php';$page_title='Home';include 'includes/header.php';?>
<section class="hero"><h1>Don't Waste Food. Share It.</h1><p>Connect surplus edible food with people who need it through donors, recipients, collectors and NGOs.</p>
<a class="btn" href="register.php">Get Started</a> <a class="btn secondary" href="available-food.php">Find Food</a></section>
<h2>How It Works</h2><div class="grid">
<div class="card"><h3>1. Donor Posts Food</h3><p>Add surplus food, photo, quantity, expiry and location.</p></div>
<div class="card"><h3>2. 15 KM Matching</h3><p>Nearby recipients, collectors and NGOs can be notified.</p></div>
<div class="card"><h3>3. Request & Accept</h3><p>Duplicate full-donation requests are prevented.</p></div>
<div class="card"><h3>4. Delivery</h3><p>Donor, collector or NGO completes the delivery.</p></div></div>
<?php include 'includes/footer.php';?>