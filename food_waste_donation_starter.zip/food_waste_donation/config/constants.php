<?php
define('BASE_URL','/food_waste_donation/');
define('UPLOAD_DIR',__DIR__.'/../uploads/food/');
define('UPLOAD_URL',BASE_URL.'uploads/food/');
define('MATCH_RADIUS_KM',15);
?>