<?php
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function redirect($u){header('Location: '.$u);exit;}
function flash($type,$msg){$_SESSION['flash']=['type'=>$type,'msg'=>$msg];}
function show_flash(){if(!empty($_SESSION['flash'])){echo '<div class="flash '.h($_SESSION['flash']['type']).'">'.h($_SESSION['flash']['msg']).'</div>';unset($_SESSION['flash']);}}
function distance_km($lat1,$lon1,$lat2,$lon2){
 $r=6371; $dlat=deg2rad($lat2-$lat1); $dlon=deg2rad($lon2-$lon1);
 $a=sin($dlat/2)**2+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dlon/2)**2;
 return $r*2*atan2(sqrt($a),sqrt(1-$a));
}
function notify($conn,$uid,$title,$message,$type='general',$related=null){
 $s=$conn->prepare('INSERT INTO notifications(user_id,title,message,type,related_id) VALUES(?,?,?,?,?)');
 $s->bind_param('isssi',$uid,$title,$message,$type,$related);$s->execute();
}
?>