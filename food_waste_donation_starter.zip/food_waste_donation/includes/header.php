<?php if(session_status()===PHP_SESSION_NONE)session_start(); ?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=h($page_title??'Food Waste Donation System')?></title>
<link rel="stylesheet" href="<?=BASE_URL?>assets/css/style.css"></head><body>
<header><a class="brand" href="<?=BASE_URL?>index.php">🍱 FoodShare</a>
<nav><a href="<?=BASE_URL?>index.php">Home</a><a href="<?=BASE_URL?>about.php">About</a><a href="<?=BASE_URL?>how-it-works.php">How It Works</a><a href="<?=BASE_URL?>available-food.php">Available Food</a>
<?php if(isset($_SESSION['user_id'])): ?><a href="<?=BASE_URL?>dashboard.php">Dashboard</a><a href="<?=BASE_URL?>logout.php">Logout</a>
<?php else: ?><a href="<?=BASE_URL?>login.php">Login</a><a href="<?=BASE_URL?>register.php">Register</a><?php endif;?></nav></header>
<main class="container"><?php show_flash(); ?>