</main><footer>Food Waste Donation System — Save Food • Share Hope • Reduce Waste</footer>
<script src="<?=BASE_URL?>assets/js/script.js"></script></body></html>